# IEEE 9-Bus Grid Simulator — Microservices Architecture

## Architecture

```
┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐
│  ns-diesel-gen   │  │   ns-battery     │  │  ns-datacenter   │
│                  │  │                  │  │                  │
│  Diesel Gen Sim  │  │  BESS Simulator  │  │  DC Load Sim     │
│  163 MW → Bus 2  │  │  85 MW → Bus 3   │  │  125 MW → Bus 5  │
│  :8001           │  │  :8002           │  │  :8003           │
└────────┬─────────┘  └────────┬─────────┘  └────────┬─────────┘
         │   POST /api/asset-update                   │
         └──────────────────┬──┬──────────────────────┘
                            │  │
                   ┌────────▼──▼────────┐
                   │   grid-central      │
                   │                     │
                   │  Newton-Raphson PF  │
                   │  IEEE 9-Bus Model   │
                   │  WebSocket → UI     │
                   │  :8000              │
                   └─────────────────────┘
```

Each asset simulator:
- Lives in its own K8s namespace (or Docker container)
- Iteratively computes its physics model every tick (~1s)
- POSTs generation/load telemetry to the central grid engine
- Serves its own monitoring frontend page via WebSocket

The central engine:
- Receives updates, maps them to IEEE 9-bus model
- Runs Newton-Raphson AC power flow
- Broadcasts results to all connected WebSocket clients
- Color-codes: 🟢 nominal, 🔴 congestion, 🟡 warning, 🔵 idle, 🟣 undervoltage

## Asset → Bus Mapping

| Asset            | Bus | Type       | Rated     |
|------------------|-----|------------|-----------|
| Diesel Generator | 2   | PV (gen)   | 163 MW    |
| Battery BESS     | 3   | PV (±gen)  | 85 MW     |
| Data Center      | 5   | PQ (load)  | 125 MW    |
| Slack Generator  | 1   | Slack      | balancing |

## Quick Start — Docker Compose

```bash
cd ieee9-grid
docker compose up --build
```

Then open:
- **Grid Dashboard**: http://localhost:8000
- **Diesel Generator**: http://localhost:8001
- **Battery BESS**: http://localhost:8002
- **Data Center**: http://localhost:8003

## Quick Start — Kubernetes

```bash
# Build and push images (replace registry)
docker build -t myregistry/grid-central:latest ./grid-central
docker build -t myregistry/diesel-gen:latest   ./diesel-gen
docker build -t myregistry/battery:latest      ./battery
docker build -t myregistry/datacenter:latest   ./datacenter

# Apply manifests
kubectl apply -f k8s-manifests.yaml
```

Each service gets its own namespace:
- `grid-central` — central power flow engine
- `ns-diesel-gen` — diesel generator simulator
- `ns-battery` — battery BESS simulator
- `ns-datacenter` — data center load simulator

Cross-namespace comms via K8s DNS:
`http://grid-central.grid-central.svc.cluster.local:8000`

## Quick Start — Local (no Docker)

```bash
# Terminal 1: Grid Central
cd grid-central
pip install -r requirements.txt
uvicorn main:app --port 8000

# Terminal 2: Diesel Gen
cd diesel-gen
pip install -r requirements.txt
uvicorn main:app --port 8001

# Terminal 3: Battery
cd battery
pip install -r requirements.txt
uvicorn main:app --port 8002

# Terminal 4: Datacenter
cd datacenter
pip install -r requirements.txt
uvicorn main:app --port 8003
```

## API Reference

### Grid Central (:8000)

| Endpoint               | Method | Description                          |
|------------------------|--------|--------------------------------------|
| `POST /api/asset-update` | POST | Receive telemetry from asset sim    |
| `GET /api/grid-state`    | GET  | Latest power flow results (polling) |
| `GET /api/topology`      | GET  | Static grid topology                |
| `WS /ws/grid`            | WS   | Real-time power flow broadcast      |

### Asset Simulators (:8001, :8002, :8003)

| Endpoint          | Method | Description                    |
|-------------------|--------|--------------------------------|
| `POST /api/setpoint` | POST | Change target load/generation |
| `GET /api/status`    | GET  | Current simulator state       |
| `WS /ws`             | WS   | Real-time telemetry stream    |

### Setpoint Examples

```bash
# Diesel gen: set to 90% load
curl -X POST http://localhost:8001/api/setpoint \
  -H "Content-Type: application/json" \
  -d '{"target_load_pct": 90}'

# Battery: discharge at 50 MW
curl -X POST http://localhost:8002/api/setpoint \
  -H "Content-Type: application/json" \
  -d '{"target_power_mw": 50}'

# Battery: charge at 30 MW
curl -X POST http://localhost:8002/api/setpoint \
  -H "Content-Type: application/json" \
  -d '{"target_power_mw": -30}'

# Datacenter: crank IT load to 95%
curl -X POST http://localhost:8003/api/setpoint \
  -H "Content-Type: application/json" \
  -d '{"it_load_pct": 95}'
```

## Simulation Models

### Diesel Generator
- Governor droop control (4% droop)
- SFC (fuel efficiency) curve — U-shaped, optimal at ~75%
- Exhaust temperature, coolant, oil pressure dynamics
- Ramp rate: 2%/s

### Battery BESS
- NMC cell OCV curve
- Round-trip efficiency: 88%
- SoC limits: 5% – 98%
- Ramp rate: 10 MW/s (fast response)
- Thermal model + HVAC cooling
- Cycle counting & SoH degradation

### Data Center
- Server power = 40% idle + 60% × utilization
- PUE model with ambient temperature dependency
- Diurnal load pattern (business hours)
- Cooling, UPS losses, misc loads breakdown

## File Structure

```
ieee9-grid/
├── docker-compose.yml
├── k8s-manifests.yaml
├── README.md
├── grid-central/
│   ├── Dockerfile
│   ├── requirements.txt
│   ├── main.py              # FastAPI — NR power flow engine
│   └── frontend/
│       └── index.html        # Grid diagram + WS dashboard
├── diesel-gen/
│   ├── Dockerfile
│   ├── requirements.txt
│   ├── main.py              # FastAPI — diesel gen physics
│   └── frontend/
│       └── index.html        # Gen control panel
├── battery/
│   ├── Dockerfile
│   ├── requirements.txt
│   ├── main.py              # FastAPI — BESS physics
│   └── frontend/
│       └── index.html        # Battery control panel
└── datacenter/
    ├── Dockerfile
    ├── requirements.txt
    ├── main.py              # FastAPI — DC load model
    └── frontend/
        └── index.html        # DC monitoring panel
```
