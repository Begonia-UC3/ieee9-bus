# IEEE 9-Bus Distributed Power Flow Simulation

Distributed power flow simulation on Cozystack/Kubernetes. Each zone is
controlled by a separate user who pushes code to GitHub; CI builds a container
image; Flux deploys it into the cluster. A central coordinator runs
pandapower power flow every 60 seconds and publishes results via NATS.

## Architecture

```
┌──────────┐  git push   ┌─────────────┐  ghcr.io   ┌──────────┐
│  User 1  │────────────▶│ GitHub Repo │───────────▶│  Flux    │
│ (Zone 1) │             │  + Actions  │            │ (deploy) │
└──────────┘             └─────────────┘            └────┬─────┘
                                                         │
                         ┌───────────────────────────────┘
                         ▼
              ┌─────────────────────┐
              │   Kubernetes Pod    │
              │  zone-1-simulator   │
              └──────────┬──────────┘
                         │ NATS: zone.1.input
                         ▼
              ┌─────────────────────┐     ┌──────────────┐
              │    Coordinator      │────▶│   Grafana    │
              │  (pandapower pf)    │     │  Dashboard   │
              └──────────┬──────────┘     └──────────────┘
                         │ NATS: zone.1.result
                         ▼
              ┌─────────────────────┐
              │  zone-1-simulator   │
              │  (receives results) │
              └─────────────────────┘
```

## NATS Topics

| Topic              | Direction       | Payload                                          |
|--------------------|-----------------|--------------------------------------------------|
| `zone.<N>.input`   | zone → coord    | `{p_gen, q_gen, p_load, q_load, zone_id}`        |
| `zone.<N>.result`  | coord → zone    | `{zone_id, converged, buses, total_loss_mw}`     |
| `grid.result`      | coord → all     | Full power flow results (all buses, lines, gens)  |

## Zone Mapping (IEEE 9-Bus)

| Zone | Generator        | Loads            | Buses (1-indexed) |
|------|------------------|------------------|-------------------|
| 1    | Gen 1 (slack)    | Load @ bus 5     | 1, 4              |
| 2    | Gen 2, Gen 3     | Load @ bus 8, 9  | 2, 7, 8, 9        |
| 3    | —                | Load @ bus 6     | 3, 5, 6           |

## Setup

### Prerequisites
- Cozystack cluster with Flux
- `*.cozystack-demo.org` DNS → cluster IP
- GitHub org/account for repos

### 1. Deploy NATS + Coordinator

```bash
kubectl apply -f k8s/nats.yaml
kubectl apply -f k8s/coordinator.yaml
kubectl apply -f k8s/monitoring.yaml
```

### 2. Create zone repos on GitHub

For each zone, create a repo from the `zone-simulator/` template:

```
github.com/org/zone-1-simulator
github.com/org/zone-2-simulator
github.com/org/zone-3-simulator
```

Each repo contains `main.py`, `requirements.txt`, `Dockerfile`,
and `.github/workflows/build.yaml`. Users modify `compute_setpoints()`
in `main.py` to implement their control strategy.

### 3. Deploy zones

Copy `k8s/zone-template.yaml` for each zone:

```bash
# Zone 1
sed 's/ZONE_NUM/1/g; s|OWNER/USER_REPO|org/zone-1-simulator|g' \
  k8s/zone-template.yaml | kubectl apply -f -

# Zone 2
sed 's/ZONE_NUM/2/g; s|OWNER/USER_REPO|org/zone-2-simulator|g' \
  k8s/zone-template.yaml | kubectl apply -f -

# Zone 3
sed 's/ZONE_NUM/3/g; s|OWNER/USER_REPO|org/zone-3-simulator|g' \
  k8s/zone-template.yaml | kubectl apply -f -
```

### 4. Import Grafana dashboard

```bash
kubectl apply -f k8s/grafana-dashboard.yaml
```

Or import `grafana/dashboard.json` manually via Grafana UI.

### 5. (Optional) Flux automation

Apply `k8s/flux/sources.yaml` to let Flux watch the main repo
and auto-deploy changes.

## User Workflow

1. Clone your zone repo
2. Edit `main.py` → modify `compute_setpoints()` with your strategy
3. `git push` → GitHub Actions builds image → pushed to ghcr.io
4. Update zone deployment image tag (or let Flux image automation do it)
5. Watch results in Grafana at `grafana.cozystack-demo.org`

## Monitoring

Coordinator exposes Prometheus metrics on `:8000/metrics`:

- `bus_voltage_pu{bus}` — voltage magnitude per bus
- `bus_angle_deg{bus}` — voltage angle per bus
- `line_loading_pct{line,from_bus,to_bus}` — line loading percentage
- `gen_p_mw{gen,bus}` / `gen_q_mvar{gen,bus}` — generator output
- `zone_active{zone}` — 1 if zone is reporting, 0 if stale
- `total_loss_mw` — total system losses
- `powerflow_duration_seconds` — power flow computation time
- `powerflow_converged_total` / `powerflow_diverged_total` — counters
