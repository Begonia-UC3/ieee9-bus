"""
IEEE 9-bus distributed power flow coordinator.

Collects zone inputs from NATS, runs pandapower power flow every cycle,
publishes results back. Zones that don't report get default values (0 MW).
Exposes Prometheus metrics on :8000/metrics.
"""

import asyncio
import json
import logging
import time
import os

import nats
import pandapower as pp
import pandapower.networks as pn
import numpy as np
from prometheus_client import start_http_server, Gauge, Counter, Histogram

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("coordinator")

# ── config ──────────────────────────────────────────────────────────────────
NATS_URL = os.getenv("NATS_URL", "nats://nats:4222")
CYCLE_SECONDS = int(os.getenv("CYCLE_SECONDS", "60"))
NUM_ZONES = int(os.getenv("NUM_ZONES", "3"))

# ── IEEE 9-bus zone mapping ─────────────────────────────────────────────────
# Zone 1: Gen @ bus 0 (slack), Load @ bus 4
# Zone 2: Gen @ bus 1,        Load @ bus 7, 8
# Zone 3: Gen @ bus 2,        Load @ bus 5, 6
ZONE_CONFIG = {
    1: {
        "gens": [0],        # gen indices in net.gen / net.ext_grid
        "loads": [0],       # load indices in net.load
        "buses": [0, 3],    # bus indices (bus 1,4 in 1-indexed)
        "is_slack": True,
    },
    2: {
        "gens": [0, 1],     # gen indices (2 generators at bus 2,3)
        "loads": [1, 2],    # loads at bus 8,9
        "buses": [1, 6, 7, 8],
        "is_slack": False,
    },
    3: {
        "gens": [],          # no controllable gen beyond what's in zone 2
        "loads": [3],        # load at bus 6 (if present)
        "buses": [2, 4, 5],
        "is_slack": False,
    },
}

# ── defaults (IEEE 9-bus standard values) ───────────────────────────────────
# These are used when a zone is not reporting
ZONE_DEFAULTS = {
    1: {"p_gen": 0.0, "q_gen": 0.0, "p_load": 0.0, "q_load": 0.0},
    2: {"p_gen": 0.0, "q_gen": 0.0, "p_load": 0.0, "q_load": 0.0},
    3: {"p_gen": 0.0, "q_gen": 0.0, "p_load": 0.0, "q_load": 0.0},
}

# ── prometheus metrics ──────────────────────────────────────────────────────
pf_duration = Histogram("powerflow_duration_seconds", "Time to run power flow")
pf_converged = Counter("powerflow_converged_total", "Converged power flow runs")
pf_diverged = Counter("powerflow_diverged_total", "Diverged power flow runs")
pf_cycle = Counter("powerflow_cycles_total", "Total power flow cycles")
zone_active = Gauge("zone_active", "Zone is reporting", ["zone"])
bus_voltage = Gauge("bus_voltage_pu", "Bus voltage magnitude [p.u.]", ["bus"])
bus_angle = Gauge("bus_angle_deg", "Bus voltage angle [deg]", ["bus"])
line_loading = Gauge("line_loading_pct", "Line loading [%]", ["line", "from_bus", "to_bus"])
gen_p = Gauge("gen_p_mw", "Generator active power [MW]", ["gen", "bus"])
gen_q = Gauge("gen_q_mvar", "Generator reactive power [Mvar]", ["gen", "bus"])
load_p = Gauge("load_p_mw", "Load active power [MW]", ["load", "bus"])
g_total_loss = Gauge("total_loss_mw", "Total system losses [MW]")
zone_p_input = Gauge("zone_p_gen_input_mw", "Zone P_gen input [MW]", ["zone"])
zone_q_input = Gauge("zone_q_gen_input_mvar", "Zone Q_gen input [Mvar]", ["zone"])


class Coordinator:
    def __init__(self):
        self.net = pn.case9()
        self.nc: nats.NATS = None
        self.zone_inputs: dict[int, dict] = {}
        self.zone_last_seen: dict[int, float] = {}
        self.lock = asyncio.Lock()

    # ── NATS ────────────────────────────────────────────────────────────────

    async def connect(self):
        self.nc = await nats.connect(NATS_URL)
        for z in range(1, NUM_ZONES + 1):
            subject = f"zone.{z}.input"
            await self.nc.subscribe(subject, cb=self._on_zone_input)
            log.info("subscribed to %s", subject)

    async def _on_zone_input(self, msg):
        try:
            data = json.loads(msg.data.decode())
            zone_id = data.get("zone_id") or int(msg.subject.split(".")[1])
            async with self.lock:
                self.zone_inputs[zone_id] = data
                self.zone_last_seen[zone_id] = time.time()
                zone_active.labels(zone=str(zone_id)).set(1)
                zone_p_input.labels(zone=str(zone_id)).set(data.get("p_gen", 0))
                zone_q_input.labels(zone=str(zone_id)).set(data.get("q_gen", 0))
            log.info("zone %d input: %s", zone_id, data)
        except Exception as e:
            log.error("bad zone input: %s – %s", msg.data, e)

    # ── power flow ──────────────────────────────────────────────────────────

    def _apply_zone_inputs(self):
        """Apply zone inputs to pandapower network, or defaults if missing."""
        net = self.net
        now = time.time()

        for zone_id in range(1, NUM_ZONES + 1):
            cfg = ZONE_CONFIG.get(zone_id, {})
            last = self.zone_last_seen.get(zone_id, 0)
            stale = (now - last) > CYCLE_SECONDS * 3

            if zone_id in self.zone_inputs and not stale:
                inp = self.zone_inputs[zone_id]
                zone_active.labels(zone=str(zone_id)).set(1)
            else:
                inp = ZONE_DEFAULTS[zone_id]
                zone_active.labels(zone=str(zone_id)).set(0)
                if stale and zone_id in self.zone_inputs:
                    log.warning("zone %d stale (last seen %.0fs ago), using defaults",
                                zone_id, now - last)

            # apply generator setpoints
            if cfg.get("is_slack"):
                # slack bus: ext_grid handles P automatically, we can set Q limits
                pass
            else:
                p_per_gen = inp.get("p_gen", 0) / max(len(cfg["gens"]), 1)
                q_per_gen = inp.get("q_gen", 0) / max(len(cfg["gens"]), 1)
                for gi in cfg["gens"]:
                    if gi < len(net.gen):
                        net.gen.at[gi, "p_mw"] = p_per_gen
                        net.gen.at[gi, "q_mvar"] = q_per_gen

            # apply load setpoints
            p_per_load = inp.get("p_load", 0) / max(len(cfg["loads"]), 1)
            q_per_load = inp.get("q_load", 0) / max(len(cfg["loads"]), 1)
            for li in cfg["loads"]:
                if li < len(net.load):
                    net.load.at[li, "p_mw"] = p_per_load
                    net.load.at[li, "q_mvar"] = q_per_load

    def _run_powerflow(self) -> bool:
        try:
            with pf_duration.time():
                pp.runpp(self.net, algorithm="nr", max_iteration=30)
            if self.net.converged:
                pf_converged.inc()
                return True
            else:
                pf_diverged.inc()
                log.warning("power flow did not converge")
                return False
        except Exception as e:
            pf_diverged.inc()
            log.error("power flow failed: %s", e)
            return False

    def _collect_results(self) -> dict:
        net = self.net
        res = {
            "timestamp": time.time(),
            "converged": bool(net.converged),
            "buses": {},
            "lines": {},
            "gens": {},
            "loads": {},
            "total_loss_mw": 0.0,
        }

        # buses
        for idx in net.res_bus.index:
            vm = float(net.res_bus.at[idx, "vm_pu"])
            va = float(net.res_bus.at[idx, "va_degree"])
            res["buses"][int(idx)] = {"vm_pu": vm, "va_degree": va}
            bus_voltage.labels(bus=str(idx + 1)).set(vm)
            bus_angle.labels(bus=str(idx + 1)).set(va)

        # lines
        total_loss = 0.0
        for idx in net.res_line.index:
            loading = float(net.res_line.at[idx, "loading_percent"])
            p_from = float(net.res_line.at[idx, "p_from_mw"])
            p_to = float(net.res_line.at[idx, "p_to_mw"])
            loss = abs(p_from + p_to)
            total_loss += loss
            fb = int(net.line.at[idx, "from_bus"])
            tb = int(net.line.at[idx, "to_bus"])
            res["lines"][int(idx)] = {
                "loading_pct": loading,
                "p_from_mw": p_from,
                "p_to_mw": p_to,
                "loss_mw": loss,
            }
            line_loading.labels(
                line=str(idx), from_bus=str(fb + 1), to_bus=str(tb + 1)
            ).set(loading)

        # transformers as lines too
        for idx in net.res_trafo.index:
            loading = float(net.res_trafo.at[idx, "loading_percent"])
            p_hv = float(net.res_trafo.at[idx, "p_hv_mw"])
            p_lv = float(net.res_trafo.at[idx, "p_lv_mw"])
            loss = abs(p_hv + p_lv)
            total_loss += loss

        res["total_loss_mw"] = total_loss
        g_total_loss.set(res["total_loss_mw"])

        # gens (ext_grid + gen)
        for idx in net.res_ext_grid.index:
            p = float(net.res_ext_grid.at[idx, "p_mw"])
            q = float(net.res_ext_grid.at[idx, "q_mvar"])
            b = int(net.ext_grid.at[idx, "bus"])
            res["gens"][f"ext_{idx}"] = {"p_mw": p, "q_mvar": q, "bus": b}
            gen_p.labels(gen=f"ext_{idx}", bus=str(b + 1)).set(p)
            gen_q.labels(gen=f"ext_{idx}", bus=str(b + 1)).set(q)

        for idx in net.res_gen.index:
            p = float(net.res_gen.at[idx, "p_mw"])
            q = float(net.res_gen.at[idx, "q_mvar"])
            b = int(net.gen.at[idx, "bus"])
            res["gens"][f"gen_{idx}"] = {"p_mw": p, "q_mvar": q, "bus": b}
            gen_p.labels(gen=f"gen_{idx}", bus=str(b + 1)).set(p)
            gen_q.labels(gen=f"gen_{idx}", bus=str(b + 1)).set(q)

        # loads
        for idx in net.res_load.index:
            p = float(net.res_load.at[idx, "p_mw"])
            q = float(net.res_load.at[idx, "q_mvar"])
            b = int(net.load.at[idx, "bus"])
            res["loads"][int(idx)] = {"p_mw": p, "q_mvar": q, "bus": b}
            load_p.labels(load=str(idx), bus=str(b + 1)).set(p)

        return res

    def _zone_results(self, full_result: dict, zone_id: int) -> dict:
        """Extract zone-specific results from full power flow."""
        cfg = ZONE_CONFIG.get(zone_id, {})
        zone_buses = cfg.get("buses", [])
        return {
            "zone_id": zone_id,
            "timestamp": full_result["timestamp"],
            "converged": full_result["converged"],
            "buses": {
                k: v for k, v in full_result["buses"].items()
                if k in zone_buses
            },
            "total_loss_mw": full_result["total_loss_mw"],
        }

    # ── main loop ───────────────────────────────────────────────────────────

    async def run_cycle(self):
        async with self.lock:
            self._apply_zone_inputs()

        converged = self._run_powerflow()
        pf_cycle.inc()

        if converged:
            result = self._collect_results()
            # update total loss metric (fix name clash)
            g_total_loss.set(result["total_loss_mw"])

            # publish full result
            await self.nc.publish(
                "grid.result",
                json.dumps(result, default=str).encode(),
            )

            # publish per-zone results
            for z in range(1, NUM_ZONES + 1):
                zr = self._zone_results(result, z)
                await self.nc.publish(
                    f"zone.{z}.result",
                    json.dumps(zr, default=str).encode(),
                )

            log.info(
                "cycle done: converged=%s loss=%.2f MW",
                converged,
                result["total_loss_mw"],
            )
        else:
            log.warning("cycle done: power flow did not converge")

    async def loop(self):
        await self.connect()
        log.info("coordinator started, cycle=%ds, zones=%d", CYCLE_SECONDS, NUM_ZONES)

        # run once immediately with defaults
        await self.run_cycle()

        while True:
            await asyncio.sleep(CYCLE_SECONDS)
            await self.run_cycle()


async def main():
    start_http_server(8000)
    log.info("prometheus metrics on :8000")
    coord = Coordinator()
    await coord.loop()


if __name__ == "__main__":
    asyncio.run(main())
