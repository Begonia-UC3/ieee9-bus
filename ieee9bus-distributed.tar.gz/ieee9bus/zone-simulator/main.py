"""
IEEE 9-bus zone simulator template.

This is the template users clone and modify for their zone.
It publishes P/Q setpoints to NATS and receives power flow results.

Users should modify the `compute_setpoints()` method to implement
their control strategy (MARL agent, optimization, manual dispatch, etc.)
"""

import asyncio
import json
import logging
import os
import time

import nats

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("zone-sim")

# ── config ──────────────────────────────────────────────────────────────────
NATS_URL = os.getenv("NATS_URL", "nats://nats:4222")
ZONE_ID = int(os.getenv("ZONE_ID", "1"))
PUBLISH_INTERVAL = int(os.getenv("PUBLISH_INTERVAL", "30"))

# ── default setpoints (IEEE 9-bus standard values) ──────────────────────────
# Zone 1: Gen1 (slack, ~71.6 MW), Load at bus 5 (125 MW, 50 Mvar)
# Zone 2: Gen2 (163 MW), Loads at bus 8,9 (90+100=190 MW)
# Zone 3: Gen3 (85 MW), Load at bus 6 (no direct load in some formulations)
ZONE_NOMINAL = {
    1: {"p_gen": 71.6, "q_gen": 27.0, "p_load": 125.0, "q_load": 50.0},
    2: {"p_gen": 163.0, "q_gen": 6.7, "p_load": 190.0, "q_load": 65.0},
    3: {"p_gen": 85.0, "q_gen": -10.9, "p_load": 0.0, "q_load": 0.0},
}


class ZoneSimulator:
    def __init__(self):
        self.nc: nats.NATS = None
        self.zone_id = ZONE_ID
        self.latest_result: dict = {}
        self.cycle_count = 0

    async def connect(self):
        self.nc = await nats.connect(NATS_URL)
        await self.nc.subscribe(
            f"zone.{self.zone_id}.result", cb=self._on_result
        )
        await self.nc.subscribe("grid.result", cb=self._on_grid_result)
        log.info("connected to NATS, zone=%d", self.zone_id)

    async def _on_result(self, msg):
        self.latest_result = json.loads(msg.data.decode())
        log.info(
            "got zone result: converged=%s",
            self.latest_result.get("converged"),
        )

    async def _on_grid_result(self, msg):
        result = json.loads(msg.data.decode())
        log.debug("grid result: loss=%.2f MW", result.get("total_loss_mw", 0))

    # ── USER: modify this method ────────────────────────────────────────────
    def compute_setpoints(self) -> dict:
        """
        Compute P/Q setpoints for this zone.

        Override this method with your control strategy:
        - MARL agent inference
        - Optimization (Pyomo, GLPK)
        - Rule-based controller
        - Manual dispatch from UI

        Returns:
            dict with keys: p_gen, q_gen, p_load, q_load (all in MW/Mvar)
        """
        # default: return nominal values
        nominal = ZONE_NOMINAL.get(self.zone_id, ZONE_NOMINAL[1])

        # example: add small random variation to simulate real conditions
        # import random
        # return {
        #     "p_gen": nominal["p_gen"] * (1 + random.uniform(-0.05, 0.05)),
        #     "q_gen": nominal["q_gen"] * (1 + random.uniform(-0.05, 0.05)),
        #     "p_load": nominal["p_load"] * (1 + random.uniform(-0.1, 0.1)),
        #     "q_load": nominal["q_load"] * (1 + random.uniform(-0.1, 0.1)),
        # }

        return dict(nominal)

    # ── main loop ───────────────────────────────────────────────────────────
    async def publish_loop(self):
        await self.connect()
        log.info("zone %d simulator started, interval=%ds", self.zone_id, PUBLISH_INTERVAL)

        while True:
            setpoints = self.compute_setpoints()
            setpoints["zone_id"] = self.zone_id
            setpoints["timestamp"] = time.time()
            setpoints["cycle"] = self.cycle_count

            await self.nc.publish(
                f"zone.{self.zone_id}.input",
                json.dumps(setpoints).encode(),
            )
            log.info(
                "published: p_gen=%.1f q_gen=%.1f p_load=%.1f q_load=%.1f",
                setpoints["p_gen"],
                setpoints["q_gen"],
                setpoints["p_load"],
                setpoints["q_load"],
            )
            self.cycle_count += 1
            await asyncio.sleep(PUBLISH_INTERVAL)


async def main():
    sim = ZoneSimulator()
    await sim.publish_loop()


if __name__ == "__main__":
    asyncio.run(main())
